# Restaurant/Food Delivery App UI kit in Flutter

We build Flutter Restaurant/Food delivery app UI Kit to help you build a nice clean app for restaurant using flutter which runs both Android and iOS. This kit comes packed with 25 beautifully designed screens and a hearty portion of deliciously responsive components. Also, we have skeleton loading and have separate components for both Android and iOS so that you feel the native experience.

## Screenshots

![All pages](/preview.png)

![Preview](/foodly_thun.png)
