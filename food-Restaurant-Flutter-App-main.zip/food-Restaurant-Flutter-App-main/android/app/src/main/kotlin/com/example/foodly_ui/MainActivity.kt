package com.example.foodly_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
